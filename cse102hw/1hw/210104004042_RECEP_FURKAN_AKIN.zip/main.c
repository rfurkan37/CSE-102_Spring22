#include <stdio.h>
#include "utils.h"

int main()
{
    printf("\t\t\t===WELCOME TO HW1 PROJECT===\n");
    printf("\t\t\t     RECEP FURKAN AKIN\n");
    part1recep();
    part2recep();

    return 0;
}
